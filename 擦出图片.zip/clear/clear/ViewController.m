//
//  ViewController.m
//  clear
//
//  Created by bean on 16/5/6.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#define kMargin 10
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor orangeColor];
    
    UIImageView *topView = [[UIImageView alloc] init];
    topView.image = [UIImage imageNamed:@"1024.png"];
    topView.frame = CGRectMake(50, 100, 200, 200);
    [self.view addSubview:topView];
    
    topView.userInteractionEnabled = YES; // 允许用户交互
    
    UIPanGestureRecognizer *panG = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panG:)];
    // 添加拖拽手势
    [topView addGestureRecognizer:panG];
}

/** 拖动的时候,擦除图片的某一部分
 *  手指拖拽的时候，清除指定位置，确定矩形区域，把控件上的内容渲染到上下文，显示清除后的图片
 *  1、开启上下文清除指定区域，将指定rect进行清除操作
 *  2、然后重新渲染顶部UIImageView，从上下文中获取清除后的上下文作为顶部UIImageView的图片显示.
 */
- (void)panG:(UIGestureRecognizer *)panG{
    
    // 1、开启位图上下文
    UIGraphicsBeginImageContextWithOptions(panG.view.frame.size, NO, 0);
    
    CGPoint curP = [panG locationInView:panG.view];
    
    // 2、清除范围
    CGRect rect = CGRectMake(curP.x, curP.y, kMargin, kMargin);
    
    // 3、 把控件上的内容渲染到上下文
    [panG.view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    // 调用上下文清除方法，将指定rect进行清除操作
    CGContextClearRect(UIGraphicsGetCurrentContext(), rect);
    
    // 从上下文获取清除后的图片
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    // 关闭位图上下文
    UIGraphicsEndImageContext();
    
    UIImageView *imageView = (UIImageView *)panG.view;
    
    imageView.image = image;
}
@end
